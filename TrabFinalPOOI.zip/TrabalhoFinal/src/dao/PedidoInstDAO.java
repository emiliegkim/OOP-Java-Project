package dao;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import modelo.PedidoInst;

public class PedidoInstDAO {

    private File arqInst = null;

    public PedidoInstDAO() {
        arqInst = new File("dadosInstalacao.txt"); //arquivo txt que armazena as informações recebidas
    }

    public boolean CadastroPedidoInst(PedidoInst inst) {
        FileWriter fw = null;
        BufferedWriter bw = null;

        try {
            fw = new FileWriter(arqInst, true);
            bw = new BufferedWriter(fw);
            bw.write(inst.toString());
            bw.flush();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } finally {
            try {
                fw.close();
                bw.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return true;
    }

}
