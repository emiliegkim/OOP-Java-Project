package dao;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import modelo.PedidoComp;


public class PedidoCompDAO {

    private File arqComp = null;

    public PedidoCompDAO() {
        arqComp = new File("dadosComputador.txt"); //arquivo txt que armazena as informações recebidas
    }

    public boolean CadastroPedidoComp(PedidoComp comp) {
        FileWriter fw = null;
        BufferedWriter bw = null;

        try {
            fw = new FileWriter(arqComp, true);
            bw = new BufferedWriter(fw);
            bw.write(comp.toString());
            bw.flush();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        } finally {
            try {
                fw.close();
                bw.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return true;
    }

}

