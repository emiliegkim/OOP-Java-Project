package dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import modelo.Usuario;

public class UsuarioDAO {

    private File arqusu;
    private FileWriter fw;
    private BufferedWriter bw;

    public UsuarioDAO() {
        arqusu= new File("usuario.txt"); //arquivo txt com login de acesso (autenticação)
    }

    public boolean autenticaUsuario(Usuario usu) {

    	boolean resp=false;

        try {
            FileReader fr= new FileReader(arqusu);
            BufferedReader br= new BufferedReader(fr);

            String linha=null;
            String[] campos= new String[2];

            while((linha=br.readLine())!=null)
            {
                campos=linha.split("#");

                if(campos[0].equals(usu.getUsu())&& campos[1].equals(usu.getSenha()))
                {
                    resp=true;
                    break;
                }
            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return resp;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return resp;
        }

        return resp;
    }

}

