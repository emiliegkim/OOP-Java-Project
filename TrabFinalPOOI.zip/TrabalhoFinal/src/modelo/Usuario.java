package modelo;

import java.util.ArrayList;
import java.util.List;

public class Usuario {
	
	private String usu,senha;

	//construtor
	public Usuario(String usu, String senha) {
		super();
		this.usu = usu;
		this.senha = senha;
	}
	
	//getters e setters
	public Usuario(){
		
	}

	public String getUsu() {
		return usu;
	}

	public void setUsu(String usu) {
		this.usu = usu;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	//to string 
	public String toString() {
		
		return usu+"#"+senha;
	}
	
	//array list
	public List<String> validaCampos(){

        ArrayList<String> listaCampos= new ArrayList<String>();

        if(usu.equals("")) {
            listaCampos.add("Usuário");
        }
        if(senha.equals("")) {
            listaCampos.add("Senha");
        }
        return listaCampos;
    }

}
