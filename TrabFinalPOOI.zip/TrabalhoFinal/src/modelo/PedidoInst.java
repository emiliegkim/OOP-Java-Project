package modelo;

import java.util.ArrayList;
import java.util.List;

public class PedidoInst {
	
	private String lot2,sala2,predio2,ramal2,desc2;

	//construtor
	public PedidoInst(String lot2, String sala2, String predio2, String ramal2, String desc2) {
		super();
		this.lot2 = lot2;
		this.sala2 = sala2;
		this.predio2 = predio2;
		this.ramal2 = ramal2;
		this.desc2 = desc2;
	}

	//getters e setters
	public PedidoInst() {
		
	}
	
	public String getLot2() {
		return lot2;
	}

	public void setLot2(String lot2) {
		this.lot2 = lot2;
	}

	public String getSala2() {
		return sala2;
	}

	public void setSala2(String sala2) {
		this.sala2 = sala2;
	}

	public String getPredio2() {
		return predio2;
	}

	public void setPredio2(String predio2) {
		this.predio2 = predio2;
	}

	public String getRamal2() {
		return ramal2;
	}

	public void setRamal2(String ramal2) {
		this.ramal2 = ramal2;
	}

	public String getDesc2() {
		return desc2;
	}

	public void setDesc2(String desc2) {
		this.desc2 = desc2;
	}
	
	//to string
	public String toString() {

        return lot2+"#"+sala2+"#"+predio2+"#"+ramal2+"#"+desc2;
    }

    //array list	
    public List<String> validaCampos(){

        ArrayList<String> listaCampos= new ArrayList<String>();

        if(lot2.equals("")) {
            listaCampos.add("Lotação*");
        }
        if(sala2.equals("")) {
            listaCampos.add("Sala*");
        }
        if(predio2.equals("")) {
            listaCampos.add("Prédio*");
        }
        if(ramal2.equals("")) {
            listaCampos.add("Ramal*");
        }
        if(desc2.equals("")) {
            listaCampos.add("Descrição*");
        }
        return listaCampos;
    }
	

}
