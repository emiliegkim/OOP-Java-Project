package visao;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JButton;

public class JanelaPedidoComp extends JPanel {
	
	private JTextField textLotacao1;
	private JTextField textSala1;
	private JTextField textRamal1;
	private JButton buttonEnviar1, buttonCancelar1;
	private JComboBox<String> boxPredio1;
	private JTextArea textDesc1;

	/**
	 * Create the panel.
	 */
	public JanelaPedidoComp() {
		setLayout(new MigLayout("", "[grow,right]", "[][][][][][][][][][][][][][][][][][][grow][]"));
		
		JLabel labelPedido1 = new JLabel("PROPLAN - PEDIDO DE NOVO COMPUTADOR");
		labelPedido1.setFont(new Font("Tahoma", Font.BOLD, 17));
		add(labelPedido1, "cell 0 0,alignx center,aligny center");
		
		JLabel labelSolicitacao1 = new JLabel("Solicitação de Novo Computador");
		labelSolicitacao1.setForeground(new Color(0, 0, 0));
		labelSolicitacao1.setBackground(new Color(0, 128, 255));
		labelSolicitacao1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		add(labelSolicitacao1, "cell 0 2,alignx center,aligny center");
		
		JLabel labelLotacao1 = new JLabel("Lotação*");
		add(labelLotacao1, "flowy,cell 0 5,alignx left");
		
		textLotacao1 = new JTextField();
		add(textLotacao1, "cell 0 6,growx");
		textLotacao1.setColumns(50);
		
		JLabel labelSala1 = new JLabel("Sala*");
		add(labelSala1, "cell 0 8,alignx left");
		
		textSala1 = new JTextField();
		add(textSala1, "cell 0 9,growx");
		textSala1.setColumns(10);
		
		JLabel labelPredio1 = new JLabel("Prédio*");
		add(labelPredio1, "cell 0 11,alignx left");
		
		boxPredio1 = new JComboBox<String>();
		boxPredio1.addItem("----");
		boxPredio1.addItem("Prédio 1");
		boxPredio1.addItem("Prédio 2");
		boxPredio1.addItem("Prédio 3");
		add(boxPredio1, "cell 0 12,growx");
		
		JLabel labelRamal1 = new JLabel("Ramal*");
		add(labelRamal1, "cell 0 14,alignx left");
		
		textRamal1 = new JTextField();
		add(textRamal1, "cell 0 15,growx");
		textRamal1.setColumns(10);
		
		JLabel labelDescricao1 = new JLabel("Descrição*");
		add(labelDescricao1, "cell 0 16,alignx left");
		
		textDesc1 = new JTextArea();
		add(textDesc1, "cell 0 18,grow");
		
		buttonEnviar1 = new JButton("Enviar");
		add(buttonEnviar1, "flowx,cell 0 19,alignx center");
		
		buttonCancelar1 = new JButton("Cancelar");
		add(buttonCancelar1, "cell 0 19");
		
		//getters e setters
	}

	public JTextField getTextLotacao1() {
		return textLotacao1;
	}

	public void setTextLotacao1(JTextField textLotacao1) {
		this.textLotacao1 = textLotacao1;
	}

	public JTextField getTextSala1() {
		return textSala1;
	}

	public void setTextSala1(JTextField textSala1) {
		this.textSala1 = textSala1;
	}

	public JTextField getTextRamal1() {
		return textRamal1;
	}

	public void setTextRamal1(JTextField textRamal1) {
		this.textRamal1 = textRamal1;
	}

	public JButton getButtonEnviar1() {
		return buttonEnviar1;
	}

	public void setButtonEnviar1(JButton buttonEnviar1) {
		this.buttonEnviar1 = buttonEnviar1;
	}

	public JButton getButtonCancelar1() {
		return buttonCancelar1;
	}

	public void setButtonCancelar1(JButton buttonCancelar1) {
		this.buttonCancelar1 = buttonCancelar1;
	}

	public JComboBox<String> getBoxPredio1() {
		return boxPredio1;
	}

	public void setBoxPredio1(JComboBox<String> boxPredio1) {
		this.boxPredio1 = boxPredio1;
	}

	public JTextArea getTextDesc1() {
		return textDesc1;
	}

	public void setTextDesc1(JTextArea textDesc1) {
		this.textDesc1 = textDesc1;
	}
	
	//para limpar a tela (informações)- é chamado no controle
	public void limparJanelaPedidoComp() {
		textLotacao1.setText("");
		textSala1.setText("");
		textRamal1.setText("");
		boxPredio1.setSelectedIndex(0);
		textDesc1.setText("");
		
	}
	

}
