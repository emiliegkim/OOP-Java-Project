package visao;

import javax.swing.JPanel;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class JanelaAutenticar extends JPanel {
	
	private JTextField fieldUsuario;
	private JPasswordField passwordField;
	private JButton buttonAutenticar, buttonCancelar;
	

	/**
	 * Create the panel.
	 */
	public JanelaAutenticar() {
		setLayout(new MigLayout("", "[30px][30px][30px][][30px][30px][30px][grow]", "[][][][][][][][][][][][][]"));
		
		JLabel labelUsuario = new JLabel("Usuário");
		add(labelUsuario, "flowy,cell 3 4,alignx center,aligny center");
		
		fieldUsuario = new JTextField();
		add(fieldUsuario, "cell 3 4,growx");
		fieldUsuario.setColumns(40);
		
		setBounds(0, 0, 665, 658); //configuração padrão de tamanho
		
		JLabel labelSenha = new JLabel("Senha");
		add(labelSenha, "flowy,cell 3 5,alignx center");
		
		passwordField = new JPasswordField();
		add(passwordField, "cell 3 5,growx,aligny center");
		
		buttonAutenticar = new JButton("Autenticar");
		add(buttonAutenticar, "flowx,cell 3 7,alignx center,aligny center");
		
		buttonCancelar = new JButton("Cancelar");
		add(buttonCancelar, "cell 3 7,alignx center");

	}

	//getters e setters

	public JTextField getFieldUsuario() {
		return fieldUsuario;
	}


	public void setFieldUsuario(JTextField fieldUsuario) {
		this.fieldUsuario = fieldUsuario;
	}


	public JPasswordField getPasswordField() {
		return passwordField;
	}


	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}


	public JButton getButtonAutenticar() {
		return buttonAutenticar;
	}


	public void setButtonAutenticar(JButton buttonAutenticar) {
		this.buttonAutenticar = buttonAutenticar;
	}


	public JButton getButtonCancelar() {
		return buttonCancelar;
	}


	public void setButtonCancelar(JButton buttonCancelar) {
		this.buttonCancelar = buttonCancelar;
	}
	
	public void limparJanelaAutentica(){
		fieldUsuario.setText("");
		passwordField.setText("");
		
	}

}
