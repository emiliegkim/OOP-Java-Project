package visao;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class JanelaPrincipal extends JFrame {

	private JPanel painelInicial;
	private JanelaAutenticar autentica=new JanelaAutenticar();;
	private JanelaPedidoComp janpc;
	private JanelaPedidoInstalacao janpi;
	private CardLayout card;
	private JMenuBar menuBar;
	private JMenu menuPrincipal, menuPROPLAN;
	private JMenuItem itemAutenticar, itemPedidoComp, itemPedidoInst;
	private JMenuItem itemSair;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		JanelaPrincipal janpri=new JanelaPrincipal();
		janpri.setVisible(true);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaPrincipal frame = new JanelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaPrincipal() {
		setTitle("Sistema de Pedidos Internos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 665, 658);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuPrincipal = new JMenu("Principal");
		menuBar.add(menuPrincipal);
		
		itemAutenticar = new JMenuItem("Autenticação");
		menuPrincipal.add(itemAutenticar);
		
		itemSair = new JMenuItem("Sair");
		menuPrincipal.add(itemSair);
		
		JMenu menuASCOM = new JMenu("ASCOM");
		menuASCOM.setEnabled(false);
		menuBar.add(menuASCOM);
		
		JMenu menuEngenharia = new JMenu("Engenharia");
		menuEngenharia.setEnabled(false);
		menuBar.add(menuEngenharia);
		
		menuPROPLAN = new JMenu("PROPLAN");
		menuPROPLAN.setEnabled(false);
		menuBar.add(menuPROPLAN);
		
		itemPedidoComp = new JMenuItem("Pedido de Novo Computador");
		menuPROPLAN.add(itemPedidoComp);
		
		itemPedidoInst = new JMenuItem("Pedido de Instalação Provisória");
		menuPROPLAN.add(itemPedidoInst);
		
		JMenu menuSEI = new JMenu("SEI");
		menuSEI.setEnabled(false);
		menuBar.add(menuSEI);
		painelInicial = new JPanel();
		painelInicial.setBorder(new EmptyBorder(5, 5, 5, 5));

		painelInicial = new JPanel();
		setContentPane(painelInicial);
		card=new CardLayout();
		painelInicial.setLayout(card);
        
        janpc=new JanelaPedidoComp();
        janpi=new JanelaPedidoInstalacao();
        painelInicial.add(new JPanel(),"Início");
        painelInicial.add(autentica,"Autenticar");
        painelInicial.add(janpc,"Pedido de Novo Computador");
        painelInicial.add(janpi,"Pedido de Instalação Provisória");
      
        
        
	}
	
	//getters e setters

	public JPanel getPainelInicial() {
		return painelInicial;
	}

	public void setPainelInicial(JPanel painelInicial) {
		this.painelInicial = painelInicial;
	}

	public JanelaAutenticar getAutentica() {
		return autentica;
	}

	public void setAutentica(JanelaAutenticar autentica) {
		this.autentica =autentica;
	}

	public CardLayout getCard() {
		return card;
	}

	public void setCard(CardLayout card) {
		this.card = card;
	}


	public JMenu getMenuPrincipal() {
		return menuPrincipal;
	}

	public void setMenuPrincipal(JMenu menuPrincipal) {
		this.menuPrincipal = menuPrincipal;
	}

	public JMenu getMenuPROPLAN() {
		return menuPROPLAN;
	}

	public void setMenuPROPLAN(JMenu menuPROPLAN) {
		this.menuPROPLAN = menuPROPLAN;
	}

	public JMenuItem getItemAutenticar() {
		return itemAutenticar;
	}

	public void setItemAutenticar(JMenuItem itemAutenticar) {
		this.itemAutenticar = itemAutenticar;
	}

	public JMenuItem getItemPedidoComp() {
		return itemPedidoComp;
	}

	public void setItemPedidoComp(JMenuItem itemPedidoComp) {
		this.itemPedidoComp = itemPedidoComp;
	}

	public JMenuItem getItemPedidoInst() {
		return itemPedidoInst;
	}

	public void setItemPedidoInst(JMenuItem itemPedidoInst) {
		this.itemPedidoInst = itemPedidoInst;
	}

	public JMenuItem getItemSair() {
		return itemSair;
	}

	public void setItemSair(JMenuItem itemSair) {
		this.itemSair = itemSair;
	}

	public JanelaPedidoComp getJanpc() {
		return janpc;
	}

	public void setJanpc(JanelaPedidoComp janpc) {
		this.janpc = janpc;
	}

	public JanelaPedidoInstalacao getJanpi() {
		return janpi;
	}

	public void setJanpi(JanelaPedidoInstalacao janpi) {
		this.janpi = janpi;
	}
	
	//para voltar para a tela inicial (branca) - no controle
	public void chamarTelaInicial() {
		card.show(painelInicial, "Início");
		
	}
	

}
