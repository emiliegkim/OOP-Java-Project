package controle;

import modelo.PedidoComp;
import modelo.PedidoInst;
import modelo.Usuario;
import visao.JanelaAutenticar;
import visao.JanelaPedidoComp;
import visao.JanelaPedidoInstalacao;
import visao.JanelaPrincipal;

public class App {
	
	public static void main(String[] args) {
		
		//JANELA PRINCIPAL
		JanelaPrincipal janela = new JanelaPrincipal();
		JanelaAutenticar janaut = new JanelaAutenticar();
		janela.setVisible(true);
		
		//USUARIO
		Usuario usu=new Usuario();
		UsuarioControle uc=new UsuarioControle(janela,usu,janaut);
		
		//PEDIDO DE COMPUTADOR
		PedidoComp pc=new PedidoComp();
		JanelaPedidoComp jpc=new JanelaPedidoComp();
		PedidoCompControle pccont=new PedidoCompControle(janela,pc,jpc);
		
		//PEDIDO DE SOLICITAÇÃO
		PedidoInst pi=new PedidoInst();
		JanelaPedidoInstalacao janpi=new JanelaPedidoInstalacao();
		PedidoInstControle picont=new PedidoInstControle(janela,pi,janpi);
		
	}

}
