package controle;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import dao.UsuarioDAO;
import modelo.Usuario;
import visao.JanelaPrincipal;
import visao.JanelaAutenticar;

public class UsuarioControle implements ActionListener {

	private JanelaPrincipal janela;
	private Usuario usuario;
	private UsuarioDAO usudao;
	private JanelaAutenticar janaut;
	
	
	public UsuarioControle(JanelaPrincipal janela, Usuario usuario, JanelaAutenticar janaut) {

		this.janela = janela;
		this.usuario = usuario;
		this.janaut=janaut;
		usudao = new UsuarioDAO();
		this.janela.getItemAutenticar().addActionListener(this);
		this.janela.getItemSair().addActionListener(this);
		this.janela.getAutentica().getButtonAutenticar().addActionListener(this);
		this.janela.getAutentica().getButtonCancelar().addActionListener(this);
	
	}
	
	//autenticação do usuário
    
	public void autenticaUsuario() {
		
		String usu= janela.getAutentica().getFieldUsuario().getText();
        String senha= janela.getAutentica().getPasswordField().getText(); 
        usuario.setUsu(usu);
        usuario.setSenha(senha);

        if(usuario.validaCampos().size()>0) {
            System.out.println("Campos "+usuario.validaCampos()+" em branco");
        }
        else {
            
            if(usudao.autenticaUsuario(usuario)) {
            	janela.getMenuPROPLAN().setEnabled(true);
            }
            else {
            	System.out.println("Usuário incorreto."); //sinalizador de login inválido
            }
        }

	}
    
	//comandos de ação
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Autenticação")) {
			janela.getCard().show(janela.getPainelInicial(), "Autenticar");

		}

		if (e.getActionCommand().equals("Sair")) {

			System.exit(0);
			
		}
		
		 if(e.getActionCommand().equals("Autenticar")) {
	            autenticaUsuario();
	            janela.getAutentica().limparJanelaAutentica();
	           
		 }
		 
		 if(e.getActionCommand().equals("Cancelar")) {
			 janela.getAutentica().limparJanelaAutentica();
			 janela.chamarTelaInicial();
			 
		 }
	}
	
	
	
	
}
