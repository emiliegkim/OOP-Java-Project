package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.PedidoCompDAO;
import dao.PedidoInstDAO;
import modelo.PedidoComp;
import modelo.PedidoInst;
import visao.JanelaPedidoInstalacao;
import visao.JanelaPrincipal;

public class PedidoInstControle implements ActionListener {
	
	private JanelaPrincipal janela;
	private PedidoInst pi;
	private PedidoInstDAO pidao;
	private JanelaPedidoInstalacao janpi;
	
	
	public PedidoInstControle(JanelaPrincipal janela, PedidoInst pi, JanelaPedidoInstalacao janpi) {
		this.janela=janela;
		this.pi=pi;
		this.janela.getItemPedidoInst().addActionListener(this);
		pidao=new PedidoInstDAO();
		this.janela.getJanpi().getButtonEnviar2().addActionListener(this);
		this.janela.getJanpi().getButtonCancelar2().addActionListener(this);
		this.janpi=janpi;
	}
	
	//enviar pedido de instalação provisória
    public void enviaPedidoInst() {
		
		String lot2=janela.getJanpi().getTextLotacao2().getText();
		String sala2=janela.getJanpi().getTextSala2().getText();
		String predio2=janela.getJanpi().getBoxPredio2().getSelectedItem().toString();
		String ramal2=janela.getJanpi().getTextRamal2().getText();
		String desc2=janela.getJanpi().getTextDesc2().getText();
		
		pi=new PedidoInst(lot2,sala2,ramal2,predio2,desc2);
		
		if(pi.validaCampos().size()>0) {
            System.out.println("Campos "+pi.validaCampos()+" em branco");
        }
        else {
            pidao.CadastroPedidoInst(pi);
            System.out.println("Pedido enviado com sucesso!"); //sinalizador de funcionalidade
        }
	}

    //comandos de ação
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Pedido de Instalação Provisória")) {
			janela.getCard().show(janela.getPainelInicial(), "Pedido de Instalação Provisória");
			

		}

		if (e.getActionCommand().equals("Sair")) {

			System.exit(0);
			
		}
		if(e.getActionCommand().equals("Enviar")) {
            enviaPedidoInst();
            
        }
        else if(e.getActionCommand().equals("Cancelar")) {
            janela.getJanpi().limparJanelaPedidoInst(); //limpar informações com o botão cancelar
        	janela.chamarTelaInicial(); //chamar a tela inicial branca com o botão cancelar
        }
		
	}

}
