package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.event.AncestorListener;

import dao.PedidoCompDAO;
import modelo.PedidoComp;
import modelo.PedidoInst;
import visao.JanelaPedidoComp;
import visao.JanelaPrincipal;

public class PedidoCompControle implements ActionListener {

	private JanelaPrincipal janela;
	private PedidoComp pc;
	private PedidoCompDAO pcdao;
	private JanelaPedidoComp jpc;
	
	
	public PedidoCompControle(JanelaPrincipal janela, PedidoComp pc,JanelaPedidoComp jpc) {
		this.janela=janela;
		this.pc=pc;
		pcdao=new PedidoCompDAO();
		this.janela.getItemPedidoComp().addActionListener(this);
		this.janela.getJanpc().getButtonEnviar1().addActionListener(this);
		this.janela.getJanpc().getButtonCancelar1().addActionListener(this);
		this.jpc=jpc;
		
	}
	
	//void para enviar pedido de computador
	public void enviaPedidoComp() {
		
		String lot=janela.getJanpc().getTextLotacao1().getText();
		String sala=janela.getJanpc().getTextSala1().getText();
		String predio=janela.getJanpc().getBoxPredio1().getSelectedItem().toString();
		String ramal=janela.getJanpc().getTextRamal1().getText();
		String desc=janela.getJanpc().getTextDesc1().getText();
		
		pc=new PedidoComp(lot,sala,ramal,predio,desc);
		
		if(pc.validaCampos().size()>0) {
            System.out.println("Campos "+pc.validaCampos()+" em branco");
        }
        else {
            pcdao.CadastroPedidoComp(pc);
            System.out.println("Pedido enviado com sucesso!"); //sinalizador de funcionalidade
        }
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Pedido de Novo Computador")) {
			janela.getCard().show(janela.getPainelInicial(), "Pedido de Novo Computador");
			
		}

		if (e.getActionCommand().equals("Sair")) {

			System.exit(0);
			
		}
		if(e.getActionCommand().equals("Enviar")) {
            enviaPedidoComp();
            
        }
        else if(e.getActionCommand().equals("Cancelar")) {
            janela.getJanpc().limparJanelaPedidoComp(); //limpar a janela ao cancelar
        	janela.chamarTelaInicial(); //levar para a página inicial branca ao cancelar
            
        	
        }
	}

}
